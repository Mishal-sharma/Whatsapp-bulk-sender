// popup.js

document.addEventListener('DOMContentLoaded', function() {
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const csvFileInput = document.getElementById('csvFileInput');
    const messageInput = document.getElementById('messageInput');
    const intervalInput = document.getElementById('intervalInput');
    const statusMessage = document.getElementById('statusMessage');

    let parsedCsvData = []; // Store the parsed CSV data

    /**
     * Parses CSV text into an array of objects.
     * Each object represents a row, with keys being the column headers.
     * @param {string} text - The raw CSV text content.
     * @returns {Array<Object>} An array of objects representing the CSV data.
     */
    function parseCSV(text) {
        const lines = text.split('\n').filter(line => line.trim() !== ''); // Split by line, remove empty lines
        if (lines.length === 0) {
            return [];
        }

        const headers = lines[0].split(',').map(header => header.trim()); // Get headers from the first line
        const data = [];

        for (let i = 1; i < lines.length; i++) {
            const values = lines[i].split(',').map(value => value.trim()); // Get values from subsequent lines
            if (values.length !== headers.length) {
                console.warn(`[popup.js] Skipping row ${i + 1} due to column mismatch: ${lines[i]}`);
                continue; // Skip rows with incorrect number of columns
            }
            const rowObject = {};
            headers.forEach((header, index) => {
                rowObject[header] = values[index];
            });
            data.push(rowObject);
        }
        return data;
    }

    // Event listener for CSV file input change
    csvFileInput.addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const csvText = e.target.result;
                    parsedCsvData = parseCSV(csvText);

                    // Validate if the CSV has a 'phone' column
                    if (parsedCsvData.length > 0 && parsedCsvData[0].hasOwnProperty('phone')) {
                        statusMessage.textContent = `CSV loaded successfully. Found ${parsedCsvData.length} entries.`;
                        statusMessage.className = 'mt-4 text-sm text-center text-green-600';
                    } else {
                        statusMessage.textContent = 'Error: CSV must contain a "phone" column.';
                        statusMessage.className = 'mt-4 text-sm text-center text-red-600';
                        parsedCsvData = []; // Clear data if invalid
                    }
                } catch (error) {
                    statusMessage.textContent = 'Error parsing CSV file. Please check format.';
                    statusMessage.className = 'mt-4 text-sm text-center text-red-600';
                    console.error("[popup.js] CSV parsing error:", error);
                    parsedCsvData = [];
                }
            };
            reader.onerror = function() {
                statusMessage.textContent = 'Error reading file.';
                statusMessage.className = 'mt-4 text-sm text-center text-red-600';
                console.error("[popup.js] File reading error:", reader.error);
                parsedCsvData = [];
            };
            reader.readAsText(file); // Read the file as text
        } else {
            parsedCsvData = [];
            statusMessage.textContent = '';
        }
    });

    /**
     * Personalizes a message template using data from a CSV row.
     * Replaces placeholders like {column_name} with actual values.
     * @param {string} template - The message template string.
     * @param {Object} dataRow - An object containing data for personalization (e.g., {name: "Alice"}).
     * @returns {string} The personalized message.
     */
    function personalizeMessage(template, dataRow) {
        let personalizedMsg = template;
        for (const key in dataRow) {
            if (dataRow.hasOwnProperty(key)) {
                const placeholder = new RegExp(`{${key}}`, 'g');
                personalizedMsg = personalizedMsg.replace(placeholder, dataRow[key]);
            }
        }
        return personalizedMsg;
    }

    // Event listener for the "Send Bulk Messages" button
    sendMessageBtn.addEventListener('click', async function() {
        const messageTemplate = messageInput.value.trim();
        const interval = parseInt(intervalInput.value, 10);

        // Input validation
        if (parsedCsvData.length === 0) {
            statusMessage.textContent = 'Please upload a valid CSV file first.';
            statusMessage.className = 'mt-4 text-sm text-center text-orange-600';
            return;
        }

        if (!messageTemplate) {
            statusMessage.textContent = 'Please enter a message template.';
            statusMessage.className = 'mt-4 text-sm text-center text-orange-600';
            return;
        }

        if (isNaN(interval) || interval < 1) {
            statusMessage.textContent = 'Please enter a valid sending interval (minimum 1 second).';
            statusMessage.className = 'mt-4 text-sm text-center text-orange-600';
            return;
        }

        statusMessage.textContent = `Initiating bulk sending to ${parsedCsvData.length} contacts...`;
        statusMessage.className = 'mt-4 text-sm text-center text-blue-600';
        sendMessageBtn.disabled = true; // Disable button during sending

        console.log("[popup.js] Sending bulk message request to background script.");

        // Send the entire bulk send request to the background script
        chrome.runtime.sendMessage({
            action: 'startBulkSend',
            contacts: parsedCsvData, // Send the full parsed data
            messageTemplate: messageTemplate,
            interval: interval
        }, (response) => {
            if (response && response.status === 'started') {
                statusMessage.textContent = 'Bulk sending initiated in background. You can close this popup.';
                statusMessage.className = 'mt-4 text-sm text-center text-green-600';
                console.log("[popup.js] Bulk sending successfully initiated in background.");
                // Optionally, close the popup automatically after initiation
                // window.close();
            } else {
                statusMessage.textContent = response.error || 'Failed to start bulk sending.';
                statusMessage.className = 'mt-4 text-sm text-center text-red-600';
                sendMessageBtn.disabled = false; // Re-enable button on failure to start
                console.error("[popup.js] Failed to initiate bulk sending:", response.error);
            }
        });

        // Clear inputs and data immediately after sending the request
        messageInput.value = '';
        csvFileInput.value = '';
        parsedCsvData = [];
    });

    // Listen for status updates from the background script (optional, if popup stays open)
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'updateStatus') {
            statusMessage.textContent = request.message;
            statusMessage.className = request.className;
            if (request.final) {
                sendMessageBtn.disabled = false; // Re-enable button when process is truly finished
            }
        }
    });

});
