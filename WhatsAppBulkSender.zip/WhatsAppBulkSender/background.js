// background.js

// Variable to store the current bulk send state (to prevent multiple simultaneous sends)
let isBulkSendingActive = false;
let currentContacts = [];
let currentMessageTemplate = '';
let currentInterval = 0;
let currentContactIndex = 0;
let sentCount = 0;
let failedCount = 0;

// Function to send status updates to the popup (if it's open)
function sendStatusUpdate(message, className, final = false) {
    chrome.runtime.sendMessage({ action: 'updateStatus', message, className, final })
        .catch(error => {
            // This catch handles the error if the popup is already closed
            console.warn("[background.js] Could not send status update to popup (likely closed):", error.message);
        });
}

// Main function to manage the bulk sending process
async function startBulkSendProcess() {
    if (isBulkSendingActive) {
        console.warn("[background.js] Bulk sending already active. Ignoring new request.");
        sendStatusUpdate("Bulk sending already in progress.", "mt-4 text-sm text-center text-orange-600");
        return;
    }

    isBulkSendingActive = true;
    currentContactIndex = 0;
    sentCount = 0;
    failedCount = 0;

    console.log(`[background.js] Starting bulk send process for ${currentContacts.length} contacts.`);
    sendStatusUpdate(`Starting bulk sending to ${currentContacts.length} contacts...`, "mt-4 text-sm text-center text-blue-600");

    for (let i = 0; i < currentContacts.length; i++) {
        currentContactIndex = i;
        const rowData = currentContacts[i];
        const phoneNumber = rowData.phone;

        if (!phoneNumber) {
            failedCount++;
            console.warn(`[background.js] Skipping row ${i + 1}: No phone number found.`);
            sendStatusUpdate(`Skipped row ${i + 1} (no phone). Sent: ${sentCount}, Failed: ${failedCount}.`, "mt-4 text-sm text-center text-orange-600");
            // Wait for interval even for skipped contacts to maintain timing
            if (i < currentContacts.length - 1) {
                await new Promise(resolve => setTimeout(resolve, currentInterval * 1000));
            }
            continue;
        }

        const personalizedMessage = personalizeMessage(currentMessageTemplate, rowData);

        console.log(`[background.js] Processing contact ${i + 1}/${currentContacts.length}: ${phoneNumber}`);
        sendStatusUpdate(`Sending message to ${phoneNumber} (${i + 1}/${currentContacts.length})...`, "mt-4 text-sm text-center text-blue-600");

        // Use a Promise to await the result of sending a single message
        try {
            const response = await new Promise(resolve => {
                // Construct the WhatsApp Web direct chat URL
                const whatsappUrl = `https://web.whatsapp.com/send?phone=${phoneNumber}&text=${encodeURIComponent(personalizedMessage)}`;

                let targetTabId = null;
                let isNewTabCreated = false;

                // Define a flag to ensure sendResponse is called only once per request
                let responseSentToBackground = false;
                const sendResultToBackground = (res) => {
                    if (!responseSentToBackground) {
                        resolve(res); // Resolve the promise with the result
                        responseSentToBackground = true;
                    }
                };

                // Set a timeout for this individual message send attempt
                const messageSendTimeout = setTimeout(() => {
                    console.warn(`[background.js] Single message send timeout for ${phoneNumber}.`);
                    sendResultToBackground({ status: 'error', error: 'Message send timed out.' });
                    if (targetTabId && isNewTabCreated) {
                        // Optionally close the tab if it was newly created and timed out
                        // chrome.tabs.remove(targetTabId);
                    }
                }, 30000); // 30 seconds timeout for a single message attempt

                // --- Find or Create WhatsApp Web Tab ---
                chrome.tabs.query({ url: "*://web.whatsapp.com/*" }, (tabs) => {
                    if (tabs.length > 0) {
                        // Found an existing WhatsApp Web tab, reuse it
                        targetTabId = tabs[0].id;
                        console.log(`[background.js] Reusing existing WhatsApp tab: Tab ID ${targetTabId}`);
                        chrome.tabs.update(targetTabId, { url: whatsappUrl, active: true }, () => {
                            if (chrome.runtime.lastError) {
                                console.error("[background.js] Error updating existing tab:", chrome.runtime.lastError.message);
                                clearTimeout(messageSendTimeout);
                                sendResultToBackground({ status: 'error', error: 'Failed to update existing WhatsApp tab.' });
                            }
                            // No need for a separate listener for update, the main listener below will catch 'complete'
                        });
                    } else {
                        // No existing WhatsApp Web tab found, create a new one
                        isNewTabCreated = true;
                        chrome.tabs.create({ url: whatsappUrl, active: true }, (newTab) => {
                            if (chrome.runtime.lastError) {
                                console.error("[background.js] Error creating new tab:", chrome.runtime.lastError.message);
                                clearTimeout(messageSendTimeout);
                                sendResultToBackground({ status: 'error', error: 'Failed to open WhatsApp chat tab.' });
                                return;
                            }
                            targetTabId = newTab.id;
                            console.log(`[background.js] New tab created for ${phoneNumber}: Tab ID ${targetTabId}`);
                        });
                    }
                });

                // Listener for tab updates (will catch both create and update)
                const listener = (updatedTabId, changeInfo, tab) => {
                    if (updatedTabId === targetTabId && changeInfo.status === 'complete' && tab.url.startsWith("https://web.whatsapp.com/")) {
                        chrome.tabs.onUpdated.removeListener(listener);
                        console.log(`[background.js] Tab ${targetTabId} loaded for ${phoneNumber}. Injecting content script.`);

                        chrome.scripting.executeScript({
                            target: { tabId: targetTabId },
                            files: ['content.js']
                        }, () => {
                            if (chrome.runtime.lastError) {
                                console.error("[background.js] Error injecting content script:", chrome.runtime.lastError.message);
                                clearTimeout(messageSendTimeout);
                                sendResultToBackground({ status: 'error', error: 'Could not inject script into WhatsApp Web tab.' });
                                // chrome.tabs.remove(targetTabId); // Uncomment to close tab on injection failure
                                return;
                            }
                            console.log(`[background.js] Content script injected into tab ${targetTabId} for ${phoneNumber}. Sending message to content script.`);

                            chrome.tabs.sendMessage(targetTabId, { action: 'clickSendButton' }, (responseFromContent) => {
                                clearTimeout(messageSendTimeout);
                                if (chrome.runtime.lastError) {
                                    console.error("[background.js] Error sending message to content script or content script failed:", chrome.runtime.lastError.message);
                                    sendResultToBackground({ status: 'error', error: 'Failed to communicate with WhatsApp Web page or content script error.' });
                                } else if (responseFromContent) {
                                    console.log(`[background.js] Received response from content script for ${phoneNumber}:`, responseFromContent);
                                    sendResultToBackground(responseFromContent);
                                } else {
                                    console.warn(`[background.js] Content script executed but did not send a response for ${phoneNumber}.`);
                                    sendResultToBackground({ status: 'error', error: 'Content script did not send a valid response.' });
                                }
                                // IMPORTANT: Uncomment the line below if you want tabs to close automatically after each attempt
                                // if (isNewTabCreated) { // Only close if we created it
                                //     chrome.tabs.remove(targetTabId);
                                // }
                            });
                        });
                    }
                };
                chrome.tabs.onUpdated.addListener(listener);
            }); // End of new Promise for single message send

            if (response.status === 'success') {
                sentCount++;
                console.log(`[background.js] Successfully sent to ${phoneNumber}`);
            } else {
                failedCount++;
                console.error(`[background.js] Failed to send to ${phoneNumber}: ${response.error || 'Unknown error'}`);
            }
        } catch (error) {
            failedCount++;
            console.error(`[background.js] Error during single message send for ${phoneNumber}:`, error);
        }

        // Update status after each message attempt
        sendStatusUpdate(`Sent: ${sentCount}, Failed: ${failedCount}. Processing ${i + 1} of ${currentContacts.length}.`, "mt-4 text-sm text-center text-gray-600");

        // Wait for the specified interval before sending the next message, unless it's the last one
        if (i < currentContacts.length - 1) {
            console.log(`[background.js] Waiting for ${currentInterval} seconds before next message...`);
            await new Promise(resolve => setTimeout(resolve, currentInterval * 1000));
            console.log(`[background.js] Finished waiting for ${currentInterval} seconds.`);
        }
    }

    // Final status update
    console.log("[background.js] Bulk sending process finished.");
    sendStatusUpdate(`Bulk sending complete! Sent: ${sentCount}, Failed: ${failedCount}.`,
        failedCount === 0 ? 'mt-4 text-sm text-center text-green-600' : 'mt-4 text-sm text-center text-red-600',
        true // Mark as final update
    );
    isBulkSendingActive = false; // Reset flag
}

// Listener for messages from the popup script (to start the bulk send)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'startBulkSend') {
        if (isBulkSendingActive) {
            sendResponse({ status: 'error', error: 'Bulk sending already active.' });
            return true;
        }

        currentContacts = request.contacts;
        currentMessageTemplate = request.messageTemplate;
        currentInterval = request.interval;

        // Start the process without awaiting here, as it's a long-running task
        // and we want to respond to the popup immediately.
        startBulkSendProcess();

        sendResponse({ status: 'started' });
        return true;
    }
    // For 'updateStatus' messages, no response is needed back to the sender (popup)
    // as they are just one-way updates.
});

// Helper function for message personalization (moved from popup.js)
function personalizeMessage(template, dataRow) {
    let personalizedMsg = template;
    for (const key in dataRow) {
        if (dataRow.hasOwnProperty(key)) {
            const placeholder = new RegExp(`{${key}}`, 'g');
            personalizedMsg = personalizedMsg.replace(placeholder, dataRow[key]);
        }
    }
    return personalizedMsg;
}
