// content.js

// Listen for messages from the background script (background.js)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Check if the received message is a 'clickSendButton' action
    if (request.action === 'clickSendButton') {
        const MAX_ATTEMPTS = 40; // Increased max attempts to 20 seconds total (40 * 500ms)
        const ATTEMPT_INTERVAL = 500; // Interval between attempts in milliseconds (0.5 seconds)
        let attempts = 0;

        console.log("Content script running on URL:", window.location.href); // Log current URL for debugging

        /**
         * Function to find the message input box and dispatch an 'input' event.
         * Returns the message input element if found, otherwise null.
         */
        function prepareMessageBox() {
            let messageInput = null;
            const selectors = [
                // NEW HIGHEST PRIORITY: Target the contenteditable div using the ._ak1r parent and .lexical-rich-text-input
                'div._ak1r div.lexical-rich-text-input > div[contenteditable="true"][role="textbox"]',
                '[data-testid="compose-box"]', // Fallback 1: Specific data-testid
                'div[contenteditable="true"][role="textbox"]', // Fallback 2: Contenteditable div with specific role
                'p.selectable-text.copyable-text', // Fallback 3: The <p> tag itself (will find its parent)
                '.selectable-text[contenteditable="true"]', // Fallback 4: Generic contenteditable with selectable-text class
                'div[contenteditable="true"]', // Fallback 5: Broadest contenteditable div
                '[aria-label="Type a message"]', // Fallback 6: Accessibility label
                '[placeholder="Type a message"]' // Fallback 7: Placeholder text
            ];

            for (let i = 0; i < selectors.length; i++) {
                const selector = selectors[i];
                console.log(`Attempting to find message input with selector: "${selector}"`);
                let foundElement = document.querySelector(selector);

                // If the selector found the <p> tag, try to get its closest contenteditable div parent
                if (selector === 'p.selectable-text.copyable-text' && foundElement) {
                    foundElement = foundElement.closest('div[contenteditable="true"]');
                    if (foundElement) {
                        console.log("Found message input via closest contenteditable parent of p.selectable-text.");
                    }
                }

                if (foundElement) {
                    messageInput = foundElement;
                    console.log(`Message input found with selector: "${selector}"`);
                    break; // Found it, stop trying other selectors
                }
            }


            if (messageInput) {
                try {
                    messageInput.focus(); // Ensure the input box is focused
                    // Dispatch an 'input' event to simulate user typing, crucial for React-based UIs
                    messageInput.dispatchEvent(new Event('input', { bubbles: true }));
                    console.log("Input event dispatched on message box.");
                    return messageInput; // Return the found input element
                } catch (inputError) {
                    console.error("Error dispatching input event on message box:", inputError);
                    return null;
                }
            }
            console.warn("WhatsApp message input box not found after all selectors (attempt " + (attempts + 1) + "). Retrying...");
            return null; // Input box not found
        }

        /**
         * Attempts to send the message, prioritizing Enter key simulation, then button click.
         * @param {HTMLElement} messageInput - The message input element.
         * @returns {boolean} True if a send attempt was initiated, false otherwise.
         */
        function attemptSendMessage(messageInput) {
            // --- Strategy 1: Simulate Enter key press on the message input box ---
            if (messageInput) {
                try {
                    console.log("Attempting to send message by simulating Enter key press...");
                    // Dispatch keydown and keyup events for the Enter key
                    messageInput.dispatchEvent(new KeyboardEvent('keydown', {
                        key: 'Enter',
                        code: 'Enter',
                        keyCode: 13,
                        which: 13,
                        bubbles: true,
                        cancelable: true
                    }));
                    messageInput.dispatchEvent(new KeyboardEvent('keyup', {
                        key: 'Enter',
                        code: 'Enter',
                        keyCode: 13,
                        which: 13,
                        bubbles: true,
                        cancelable: true
                    }));
                    console.log("Enter key events dispatched.");

                    // Give WhatsApp a moment to process the Enter key press
                    setTimeout(() => {
                        // Check if message was sent (e.g., input box is empty or send button is gone)
                        // This is a heuristic, not a definitive check, but often works.
                        const currentMessage = messageInput.innerText.trim();
                        if (currentMessage === '') {
                            console.log("Message likely sent via Enter key (input box is empty).");
                            clearInterval(intervalId); // Stop polling
                            sendResponse({ status: 'success' }); // Indicate success
                        } else {
                            console.log("Message still in box after Enter key. Falling back to button click.");
                            // If Enter didn't clear the box, try clicking the button
                            attemptButtonClick();
                        }
                    }, 1000); // Short delay (1 second) to allow Enter key to process

                    return true; // Indicates an attempt was made via Enter key
                } catch (keyError) {
                    console.error("Error simulating Enter key press:", keyError);
                    // Fallback to button click if key press fails
                    attemptButtonClick();
                    return true; // Indicates an attempt was made (will fall back to click)
                }
            } else {
                // If message input not found, directly attempt button click as a last resort
                console.warn("Message input not found for Enter key simulation. Attempting button click directly.");
                attemptButtonClick();
                return true; // Indicates an attempt was made
            }
        }

        /**
         * Helper function to find and click the send button using MouseEvent.
         */
        function attemptButtonClick() {
            const sendButton = document.querySelector('[data-testid="send"]');
            // Also try selecting the SVG inside the button, as sometimes event listeners are on the inner element
            const sendButtonSVG = document.querySelector('[data-testid="send"] svg');

            if (sendButton) {
                console.log("Send button found. Is it disabled?", sendButton.disabled);
                try {
                    // Try dispatching MouseEvent on the button
                    sendButton.dispatchEvent(new MouseEvent('click', {
                        bubbles: true,
                        cancelable: true,
                        view: window
                    }));
                    console.log("Send button clicked using MouseEvent.");
                    clearInterval(intervalId); // Stop polling
                    sendResponse({ status: 'success' }); // Indicate success
                    return true;
                } catch (clickError) {
                    console.error("Error clicking WhatsApp send button with MouseEvent:", clickError);
                }
            } else if (sendButtonSVG) { // Try clicking the SVG if button itself didn't work
                console.log("Send button (SVG) found.");
                try {
                    sendButtonSVG.dispatchEvent(new MouseEvent('click', {
                        bubbles: true,
                        cancelable: true,
                        view: window
                    }));
                    console.log("Send button SVG clicked using MouseEvent.");
                    clearInterval(intervalId); // Stop polling
                    sendResponse({ status: 'success' }); // Indicate success
                    return true;
                } catch (svgClickError) {
                    console.error("Error clicking WhatsApp send button SVG with MouseEvent:", svgClickError);
                }
            }

            console.log("WhatsApp send button not clickable (attempt " + (attempts + 1) + "). Retrying...");
            return false; // Button not found or click failed
        }


        // Main polling loop
        const intervalId = setInterval(() => {
            attempts++;

            const messageInput = prepareMessageBox(); // Get the message input element

            // Only attempt to send if the message input box is found
            if (messageInput) {
                attemptSendMessage(messageInput); // This function handles sending and stopping the interval
            }


            // If max attempts reached and message not sent (interval not cleared by attemptSendMessage)
            if (attempts >= MAX_ATTEMPTS) {
                console.error("Max attempts reached. WhatsApp message not sent.");
                clearInterval(intervalId); // Stop polling
                sendResponse({ status: 'error', error: 'WhatsApp message not sent after multiple attempts. Ensure the chat page is fully loaded and the number is valid.' });
            }
        }, ATTEMPT_INTERVAL);

        // Return true to indicate that sendResponse will be called asynchronously.
        return true;
    }
});
